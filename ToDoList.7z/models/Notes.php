<?php
    class Notes {
        protected $mysqli;
        
        function __construct(){
            $this->mysqli = new Database();
        }
        
        public function get(){
            $notes = $this->mysqli->select(null, 'notes');
            return $notes;
        }
        
        public function create(){
            $date = date('Y-m-d');
            $hours = date('H:i:s');
            $note = $this->mysqli->getHandle()->real_escape_string($_POST['note']);
            $done = ($_POST['done']=='yes') ? 'yes' : 'no';
            return $this->mysqli->create('notes', [
                'id' => null,
                'date' => $date,
                'hours' => $hours,
                'note' => $note,
                'user_id' => 1,
                'done' => $done
            ]);
        }      
        
        public function update(){
            
        }
        
        public function delete($id){
            return $this->mysqli->delete($id, 'notes');
        }
        
    }