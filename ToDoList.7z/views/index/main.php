<?php include 'views/header.php'; ?>
<div style="margin: auto; width: 50%;">
    <h1>
        Here is your notes :D
    </h1>
    <table id="t1">
    </table>
    <table>
        <tr>

                <td colspan="3" >
                    <textarea rows="7" cols="40" name="note"></textarea><br />
                </td>
                <td>
                    <input type="radio" name="done" value="yes" />yes <br />
                    <input type="radio" name="done" value="no" />no <br />
                </td>
                <td>
                    <button>Submit</button>
                </td>
        </tr>
    </table>
    
</div>
<script type="text/javascript" >
    $(document).ready(function(){
        $(document).on('click', '.delete', function(e){
            e.preventDefault();
            $.get("index/delete/" + this.getAttribute("href"), function(){show();});
            return false;
        });
        $("button").click(function(e){
            var textarea = $('textarea').val();
            var done = $('input:checked').val();
            $.post("index/create",
            {      
                note: textarea,
                done: done
            }, 
            function(){
                show();
            }
            );
        });
        show();
    });
    function show(){
        $.get('index/getjson', function(data, status){
            $("#t1").empty();
            data = $.parseJSON(data);
            $.each(data, function(name, value){
                var output = '';
                output += "<tr>";
                output += "<td>" + value.date + "</td>";
                output += "<td>" + value.hours + "</td>";
                output += "<td>" + value.note + "</td>";
                output += "<td>" + value.done + "</td>";
                output += "<td><a class=\"delete\" href=\"" +  + value.id + "\">X</a></td>";
                output += "</tr>";
                $("#t1").append(output);
            })
        });
    }
    
    
</script>
<?php include 'views/footer.php'; ?>