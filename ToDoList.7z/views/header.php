<html>
    <head>
        <title>
            My first ToDoList in MVC. 
        </title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <style>
            td {
                padding: 3px;
            }
        </style>
    </head>
    <body>
        
    