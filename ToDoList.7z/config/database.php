<?php
    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $databasename = 'todolist';