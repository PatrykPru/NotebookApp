<?php
    class Help extends Controller {
        function Index(){
            $view = new View;
            $view->Render(__CLASS__, null);
        }
    }