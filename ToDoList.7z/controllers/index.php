<?php
    class Index extends Controller {
        
        public function main(){
            $view = new View;
            $notes = new Notes;
            $view->Render(__CLASS__, __FUNCTION__, $notes->get());
        }
        
        public function create(){
            $notes = new Notes;
            $result = $notes->create();
            header("Location: /todolist");
        }
        
        public function delete($id){
            $notes = new Notes;
            $notes->delete($id);
            header("Location: /todolist");
        }
        
        public function getJSON(){
            $notes = new Notes;
            echo json_encode($notes->get());
        }
        
        public function test(){
            
        }
    }