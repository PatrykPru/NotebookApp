<?php
    class Controller {
        
        function __construct(){
            
        }
        
    }