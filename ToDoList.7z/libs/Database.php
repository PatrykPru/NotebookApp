<?php 
    class Database {
        public $mysqli = null;
        
        function __construct(){
            require 'config/database.php';
            $mysqli = new mysqli($servername, $username, $password);
            if($mysqli->connect_error){
                die('Connection failed: '.$this->mysqli->connect_error);
            }
            $mysqli->select_db($databasename);
            $this->mysqli = $mysqli;
        }
        
        
        /**
        * @parm $where name of table
        * @parm $data array with data to create in db
        */
        public function create($where, $data){
            $sql = 'INSERT INTO '.$where.' ';
            $columns = '';
            $values = '';
            foreach($data as $name => $value){
                $columns .= '`'.$name.'`, ';
                $values .= (is_null($value)) ? 'NULL, ' : '\''.$value.'\', ';
            }
            $columns = '('.rtrim($columns, ', ').')';
            $values = '('.rtrim($values, ', ').')';
            $sql .= $columns.' VALUES '.$values.';';
            return $this->mysqli->query($sql);
        }
        
        
        /**
        * @parm $what - array with columns to given
        * @parm $from - name of table
        * @parm $limit array ['start' => 0, 'amount' => 10]
        * with start record and amount to return
        * @parm $order - ['col_name' => 'ASC', 'col_name_2' => 'DESC']
        */
        public function select($what = null, $from = false, $limit = false, $order = false){
            $output = [];
            $sql = 'SELECT ';
            $_what = (is_null($what)) ? '*' : ' ';
            if(!is_null($what)){
                foreach($what as $name => $value){
                    $_what .= '`'.$value.'`,';
                }
                $_what = rtrim($_what, ',');
            }
            $sql .= $_what;
            $sql .= ' FROM `'.$from.'`';
            if($limit)
                $sql .= ' LIMIT '.$limit['start'].','.$limit['amount'].' ';
            if(is_array($order)){
                $_order = 'ORDER BY ';
                foreach($order as $name => $value){
                    $_order .= '`'.$name.'` '.$value.', ';
                }
                $_order = rtrim($_order, ', ');
                $sql .= $_order;
            }
            $sql = $this->mysqli->real_escape_string($sql);
            $query = $this->mysqli->query($sql);
            while($result = $query->fetch_array(MYSQLI_ASSOC)){
                $output[] = $result;
            }
            return $output;
        }
        
        /**
        * @parm $id element that will be update
        * @parm $where table name
        * @parm $data array with updated data
        */
        public function update($id, $where, $data){
            $sql = 'UPDATE `'.$where.'` SET ';
            $dataUpdated = '';
            foreach($data as $name => $value){
                $dataUpdated .= '`'.$name.'` = \''.$value.'\', ';
            }
            $dataUpdated = rtrim($dataUpdated, ', ');
            $sql .= $dataUpdated;
            $sql .= ' WHERE `id` = '.$id.';';
            return $this->mysqli->query($sql);          
        }
        
        /**
        * @parm $where element's id or information about records to update
        * @pram $from table name
        */
        public function delete($where, $from){
            $sql = 'DELETE FROM `'.$from.'` WHERE ';
            if(is_array($where)){
                foreach($where as $name => $value){
                    $sql .= '`'.$name.'` = \''.$value.'\','; 
                }
                $sql = rtrim($sql, ', ');
            } 
            elseif(is_numeric($where)){
               $sql .= '`id` = '.$where; 
            }
            else {
                return 0;
            }
            return $this->mysqli->query($sql);
        }
        
        public function query($str){
            return $this->mysqli->query($str);
        }
        
        public function getHandle(){
            return $this->mysqli;
        }
        
        function __destruct(){
            $this->mysqli->close();
        }
    }